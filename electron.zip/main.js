const { ElectronEgg } = require('ee-core');
new ElectronEgg();